enum AppSecrets {
    static let googleAPIKey = "AIzaSyDey9OgT-0JDynDKpblQJk3IWTXRjV8doQ"
}
//
//  AppSecrets.example.swift
//  VoiceMap
//
//  Created by Vignesh Balaji on 8/9/25.
//

