import Foundation
import CoreLocation

struct AIResponse: Codable {
    let response: String
    let error: String?
}

class AIService {
    private let session = URLSession.shared
    private let baseURL = "https://api.openai.com/v1/chat/completions"
    private let placesService = GooglePlacesService()
    private let promptManager = PromptManager.shared
    
    // TODO: Move to secure storage or environment variable
    private let apiKey = "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"
    
    func processVoiceRequest(_ request: VoiceRequest) async throws -> String {
        let prompt = createStrategyPrompt(from: request)
        
        print("🧠 Getting AI strategy for: \(request.speech)")
        
        // First, get AI's enhanced strategy analysis using dedicated strategy method
        let aiResponse = try await getStrategyResponse(prompt: prompt)
        
        print("🔍 AI Strategy Response: \(aiResponse)")
        
        // Parse enhanced search intent
        let enhancedIntent = AIResponseParser.parseEnhancedSearchIntent(from: aiResponse)
        
        if enhancedIntent.needsPlacesSearch {
            return try await processEnhancedSearch(enhancedIntent, request: request)
        } else {
            // No places search needed, return the natural language response text
            return enhancedIntent.responseText
        }
    }
    
    private func processEnhancedSearch(_ intent: EnhancedSearchIntent, request: VoiceRequest) async throws -> String {
        let userLocation = CLLocation(latitude: request.location.latitude, longitude: request.location.longitude)
        
        // Check if we have a data strategy from AI
        if let strategy = intent.dataStrategy {
            print("🎯 Using AI-defined strategy: \(strategy.queryType.rawValue), complexity: \(strategy.complexity.rawValue)")
            return try await executeIntelligentSearch(strategy: strategy, userLocation: userLocation, request: request)
        }
        
        // Fallback to legacy basic search
        print("🔄 Falling back to legacy search for: \(intent.searchQuery ?? "unknown")")
        return try await executeLegacySearch(intent: intent, userLocation: userLocation, request: request)
    }
    
    private func executeIntelligentSearch(strategy: DataStrategy, userLocation: CLLocation, request: VoiceRequest) async throws -> String {
        
        // Check for multi-stage query
        if strategy.queryType == .multiStageSearch {
            return try await executeMultiStageSearch(strategy: strategy, userLocation: userLocation, request: request)
        }
        
        // Execute intelligent single-stage search
        let enhancedPlaces = try await placesService.intelligentSearch(
            strategy: strategy,
            location: userLocation,
            radius: 3000
        )
        
        print("✨ Enhanced search completed: \(enhancedPlaces.count) places analyzed")
        
        // Format enhanced results for AI response
        let placesData = placesService.formatEnhancedPlacesForAI(
            places: enhancedPlaces,
            userLocation: userLocation,
            strategy: strategy
        )
        
        print("📋 Data sent to LLM:")
        print(placesData)
        
        // Generate final response with enhanced data
        let finalPrompt = promptManager.finalResponsePrompt(
            speech: request.speech,
            latitude: request.location.latitude,
            longitude: request.location.longitude,
            placesData: placesData
        )
        
        return try await getFinalResponse(prompt: finalPrompt)
    }
    
    private func executeMultiStageSearch(strategy: DataStrategy, userLocation: CLLocation, request: VoiceRequest) async throws -> String {
        print("🔗 Executing multi-stage search")
        
        // This is a placeholder for complex multi-stage logic
        // For now, implement a simplified version
        
        // Stage 1: Search for primary locations
        guard let primaryQuery = extractPrimaryQuery(from: request.speech) else {
            return "I couldn't understand the multi-stage search request."
        }
        
        print("🎯 Stage 1: Searching for '\(primaryQuery)'")
        let primaryPlaces = try await placesService.searchNearby(
            query: primaryQuery,
            location: userLocation,
            radius: 10000 // Larger radius for anchor locations
        )
        
        guard !primaryPlaces.isEmpty else {
            return "I couldn't find any \(primaryQuery) locations near you."
        }
        
        // Stage 2: Search for secondary near primary locations
        guard let secondaryQuery = extractSecondaryQuery(from: request.speech) else {
            return "I found \(primaryPlaces.count) \(primaryQuery) locations, but couldn't understand what to search for near them."
        }
        
        print("🎯 Stage 2: Searching for '\(secondaryQuery)' near \(primaryPlaces.count) primary locations")
        
        var allSecondaryResults: [EnhancedPlaceResult] = []
        
        // Search near each primary location
        for primaryPlace in primaryPlaces.prefix(3) { // Limit to top 3 primary locations
            let primaryLocation = CLLocation(
                latitude: primaryPlace.location.lat,
                longitude: primaryPlace.location.lng
            )
            
            let secondaryPlaces = try await placesService.searchNearby(
                query: secondaryQuery,
                location: primaryLocation,
                radius: 2000 // Smaller radius around each primary location
            )
            
            // Convert to enhanced results with context
            for secondaryPlace in secondaryPlaces.prefix(2) { // Top 2 per primary location
                let enhancedPlace = EnhancedPlaceResult(
                    basicPlace: secondaryPlace,
                    reviewAnalysis: nil,
                    attributeScores: ["proximity_to_\(primaryQuery)": 1.0],
                    confidenceScore: 0.8,
                    ranking: nil
                )
                allSecondaryResults.append(enhancedPlace)
            }
        }
        
        // Sort by distance from user
        allSecondaryResults.sort { place1, place2 in
            let loc1 = CLLocation(latitude: place1.basicPlace.location.lat, longitude: place1.basicPlace.location.lng)
            let loc2 = CLLocation(latitude: place2.basicPlace.location.lat, longitude: place2.basicPlace.location.lng)
            return userLocation.distance(from: loc1) < userLocation.distance(from: loc2)
        }
        
        // Format multi-stage results
        let placesData = formatMultiStageResults(
            primaryQuery: primaryQuery,
            secondaryQuery: secondaryQuery,
            secondaryResults: Array(allSecondaryResults.prefix(5)),
            userLocation: userLocation
        )
        
        let finalPrompt = promptManager.multiStageResponsePrompt(
            speech: request.speech,
            primaryQuery: primaryQuery,
            secondaryQuery: secondaryQuery,
            placesData: placesData
        )
        
        return try await getFinalResponse(prompt: finalPrompt)
    }
    
    private func executeLegacySearch(intent: EnhancedSearchIntent, userLocation: CLLocation, request: VoiceRequest) async throws -> String {
        guard let searchQuery = intent.searchQuery else {
            return intent.responseText
        }
        
        print("🔍 Legacy search for: \(searchQuery)")
        
        let places = try await placesService.searchNearby(
            query: searchQuery,
            location: userLocation,
            radius: intent.radius ?? 2000
        )
        
        let placesData = placesService.formatPlacesForAI(places: places, userLocation: userLocation)
        
        print("📋 Legacy search data sent to LLM:")
        print(placesData)
        
        let finalPrompt = promptManager.finalResponsePrompt(
            speech: request.speech,
            latitude: request.location.latitude,
            longitude: request.location.longitude,
            placesData: placesData
        )
        
        return try await getFinalResponse(prompt: finalPrompt)
    }
    
    // MARK: - Strategy Response (Returns JSON for parsing)
    
    private func getStrategyResponse(prompt: String) async throws -> String {
        let payload: [String: Any] = [
            "model": "gpt-4o-mini",
            "messages": [
                [
                    "role": "system", 
                    "content": promptManager.strategySystemPrompt
                ],
                [
                    "role": "user", 
                    "content": prompt
                ]
            ],
            "max_tokens": 400,
            "temperature": 0.1 // Lower temperature for more consistent JSON formatting
        ]
        
        return try await makeAPIRequest(payload: payload)
    }
    
    // MARK: - Final Response (Returns natural language for text-to-speech)
    
    private func getFinalResponse(prompt: String) async throws -> String {
        let payload: [String: Any] = [
            "model": "gpt-4o-mini",
            "messages": [
                [
                    "role": "system", 
                    "content": promptManager.finalResponseSystemPrompt
                ],
                [
                    "role": "user", 
                    "content": prompt
                ]
            ],
            "max_tokens": 150,
            "temperature": 0.7
        ]
        
        return try await makeAPIRequest(payload: payload)
    }
    
    // MARK: - Common API Request Method
    
    private func makeAPIRequest(payload: [String: Any]) async throws -> String {
        var urlRequest = URLRequest(url: URL(string: baseURL)!)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.httpBody = try JSONSerialization.data(withJSONObject: payload)
        
        let (data, response) = try await session.data(for: urlRequest)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            print("No HTTP response")
            throw NSError(domain: "AIService", code: 1, userInfo: [NSLocalizedDescriptionKey: "No HTTP response"])
        }
        
        print("HTTP Status Code: \(httpResponse.statusCode)")
        if let responseString = String(data: data, encoding: .utf8) {
            print("Response body: \(responseString)")
        }
        
        guard httpResponse.statusCode == 200 else {
            throw NSError(domain: "AIService", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: "API request failed with status \(httpResponse.statusCode)"])
        }
        
        let result = try JSONSerialization.jsonObject(with: data) as! [String: Any]
        let choices = result["choices"] as! [[String: Any]]
        let message = choices[0]["message"] as! [String: Any]
        let content = message["content"] as! String
        
        return content.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    // MARK: - Strategy Prompt Creation
    
    private func createStrategyPrompt(from request: VoiceRequest) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        let timestamp = formatter.string(from: request.timestamp)
        
        return promptManager.strategyPrompt(
            speech: request.speech,
            latitude: request.location.latitude,
            longitude: request.location.longitude,
            timestamp: timestamp
        )
    }
    
    // MARK: - Multi-Stage Helper Functions
    
    private func extractPrimaryQuery(from speech: String) -> String? {
        let lowercased = speech.lowercased()
        
        // Common patterns for multi-stage queries
        let patterns = [
            "near ([^\\s]+)",
            "close to ([^\\s]+)",
            "around ([^\\s]+)",
            "by ([^\\s]+)"
        ]
        
        for pattern in patterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive),
               let match = regex.firstMatch(in: speech, options: [], range: NSRange(speech.startIndex..., in: speech)),
               let range = Range(match.range(at: 1), in: speech) {
                return String(speech[range]).trimmingCharacters(in: .whitespacesAndNewlines)
            }
        }
        
        return nil
    }
    
    private func extractSecondaryQuery(from speech: String) -> String? {
        let lowercased = speech.lowercased()
        
        // Extract what they're looking for (before "near/close to")
        let beforeNearPattern = "find ([^\\s]+).*?near"
        if let regex = try? NSRegularExpression(pattern: beforeNearPattern, options: .caseInsensitive),
           let match = regex.firstMatch(in: speech, options: [], range: NSRange(speech.startIndex..., in: speech)),
           let range = Range(match.range(at: 1), in: speech) {
            return String(speech[range]).trimmingCharacters(in: .whitespacesAndNewlines)
        }
        
        return nil
    }
    
    private func formatMultiStageResults(primaryQuery: String, secondaryQuery: String, secondaryResults: [EnhancedPlaceResult], userLocation: CLLocation) -> String {
        if secondaryResults.isEmpty {
            return "No \(secondaryQuery) locations found near \(primaryQuery) locations."
        }
        
        var result = "Found \(secondaryResults.count) \(secondaryQuery) locations near \(primaryQuery):\n"
        
        for (index, enhancedPlace) in secondaryResults.enumerated() {
            let place = enhancedPlace.basicPlace
            let placeLocation = CLLocation(latitude: place.location.lat, longitude: place.location.lng)
            let distance = userLocation.distance(from: placeLocation)
            let distanceInMiles = distance * 0.000621371 // Convert meters to miles
            let distanceText = distanceInMiles < 0.1 ? String(format: "%.0f ft", distance * 3.28084) : String(format: "%.1f mi", distanceInMiles)
            
            result += "\(index + 1). \(place.name)"
            if let vicinity = place.vicinity {
                result += " at \(vicinity)"
            }
            result += " - \(distanceText) from you"
            
            if let rating = place.rating {
                result += ", rated \(rating) stars"
            }
            
            result += "\n"
        }
        
        return result
    }
    
    private func createPrompt(from request: VoiceRequest) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        let timestamp = formatter.string(from: request.timestamp)
        
        return """
        User request: "\(request.speech)"
        
        Current location: 
        - Latitude: \(String(format: "%.6f", request.location.latitude))
        - Longitude: \(String(format: "%.6f", request.location.longitude))
        - Accuracy: \(String(format: "%.0f", request.location.accuracy))m
        - Time: \(timestamp)
        
        Based on their exact coordinates, provide a helpful response about nearby places, directions, or local information. Be specific about locations, street names, and walking distances when possible.
        """
    }
}
