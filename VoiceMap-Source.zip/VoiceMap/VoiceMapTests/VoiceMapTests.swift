//
//  VoiceMapTests.swift
//  VoiceMapTests
//
//  Created by Vignesh Balaji on 8/9/25.
//

import Testing
@testable import VoiceMap

struct VoiceMapTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
